#!/bin/sh

# configuration
export INST_ID=jamwiki

/prod/${INST_ID}/bin/stop.sh

exit 0

