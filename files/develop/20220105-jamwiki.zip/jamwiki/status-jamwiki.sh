#!/bin/sh

echo "---------------- jamwiki ----------------"
ps -ef | grep -v grep | grep -v '.sh' | grep -v rotatelogs | grep -v tail | grep jamwiki
echo ""

exit 0
