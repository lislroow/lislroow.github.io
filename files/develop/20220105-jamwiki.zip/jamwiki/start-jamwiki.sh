#!/bin/sh

# configuration
export JAVA_HOME=/prod/java/jdk1.8.0_202
export PATH=$JAVA_HOME/bin:$PATH
export INST_ID=jamwiki

/prod/${INST_ID}/bin/start.sh

exit 0
